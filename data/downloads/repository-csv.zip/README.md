# AI and Law in India: scholarship repository database

Generated 2026-11-18 17:04 from `Repository Master.xlsx` (schema version 1.0).
423 papers, 749 authors, 114 journals.

The same data is provided three ways:

- `repository.sqlite`: a single-file SQLite database. Open it with DB Browser for SQLite, Python, R, or import it into PostgreSQL / Supabase.
- `csv/`: one CSV per table (UTF-8). Opens in Excel; imports into any database or spreadsheet.
- `repository.json`: the website's data file, with authors and journal tier nested inside each paper.

## Tables

### papers
| Field | Meaning |
|---|---|
| paper_id | Permanent ID (P0001...). Never changes or gets reused. |
| title | As printed on the article. |
| abstract | The official abstract, verbatim. Seven papers with no published abstract carry the AI Lab Catalogue's notes instead (see internal_notes). |
| keywords | Author-supplied keywords, separated by "; ". Blank if none were printed or none were found yet. |
| publication_date | As printed: YYYY-MM-DD, YYYY-MM, YYYY, or YYYY (season / months). |
| date_sort | Sortable form of the date. Unknown month or day is 00, so year-only papers sort after dated papers of the same year when listed newest first. |
| year | Publication year. |
| date_precision | day, month, month range, season or year. |
| journal_id | Links to journals. |
| volume_issue, pages | As printed. |
| doi | Bare DOI (10.xxxx/...), if the paper has one. |
| link | Best stable link to the paper. |
| date_added | When the paper entered the repository. |
| internal_notes | Record-keeping: where the data came from, open questions. Not meant for public display or search. |

### authors
One row per person. `author_id` is derived from the name, so it is stable while the spelling is. Spellings of the same person have been merged only on evidence (same institution, shared co-authors or ORCID).

### paper_authors
Who wrote which paper, in byline order (`position`). Designation, institution and location are as printed in that paper, so a person who moved institutions keeps the right affiliation on each paper.

### journals
One row per venue, with the tier and the evidence for it (`tier_basis`, `tier_sources`, `last_verified`).

### tiers
| Tier | Meaning |
|---|---|
| A1 | Indexed, top half (Q1-Q2): Indexed in Scopus or Web of Science, ranked Q1 or Q2 in its best category, with stated peer review. |
| A2 | Indexed, lower half (Q3-Q4): Indexed in Scopus or Web of Science, ranked Q3 or Q4 (or not yet ranked), with stated peer review. |
| B | Established peer-reviewed: Not indexed, but run by an NLU or established institution, with stated blind peer review. |
| C | Review unclear / student-run: Institutional or student-edited, but peer review not stated as blind, or a new journal with no track record. |
| D | Low reliability: No stated peer review, pay-to-publish with rapid acceptance, or other predatory indicators. |
| P | Preprint, not peer reviewed: SSRN, arXiv, working papers and other unreviewed postings. |

### provenance
How each paper was found and how its abstract was retrieved, where recorded.

## Searching the SQLite file

`papers_fts` is a full-text index over title, keywords, authors and abstract, with English word stemming.
Rank with bm25(); lower scores are better. The weights below favour title, then keywords, authors and abstract:

```sql
SELECT f.paper_id, p.title, j.tier, p.year,
       bm25(papers_fts, 0, 10.0, 7.0, 6.0, 4.0) AS score
FROM papers_fts f
JOIN papers p ON p.paper_id = f.paper_id
JOIN journals j ON j.journal_id = p.journal_id
WHERE papers_fts MATCH 'deepfake* AND (regulat* OR "IT Rules")'
  AND j.tier IN ('A1','A2','B')
ORDER BY score
LIMIT 20;
```

The `papers_full` view gives one readable row per paper with authors, journal and tier joined in.
